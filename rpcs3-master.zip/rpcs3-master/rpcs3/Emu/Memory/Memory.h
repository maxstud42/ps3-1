#pragma once

#include "MemoryBlock.h"

extern VirtualMemoryBlock RSXIOMem;

#include "vm.h"
