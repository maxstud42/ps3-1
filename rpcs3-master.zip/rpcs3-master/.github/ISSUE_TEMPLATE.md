<!---

THIS IS NOT A SUPPORT FORUM, FOR SUPPORT GO TO:
https://forums.rpcs3.net
or our discord:
https://discord.me/RPCS3

PLEASE READ THE GUIDELINES BEFORE OPENING AN ISSUE:
https://github.com/RPCS3/rpcs3/blob/master/.github/CONTRIBUTING.md

====================================================

When submitting an issue, please check the following:

- You have read the above.
- You have provided the version (commit hash) of RPCS3 you are using.
- You have provided sufficient detail for the issue to be reproduced.
- You have provided system specs.
- Please also provide:
  - For crashes, a backtrace.
  - For graphical issues, comparison screenshots with real hardware.

Remember that the GitHub Issue Tracker is not the place to ask for support or to submit Game Compatibility reports. You must use our forums for that.
--->