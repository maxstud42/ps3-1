#include "stdafx.h"

TEST_CLASS(UnitTest1)
{
	TEST_METHOD(TestMethod1)
	{
		setup_ps3_environment();
	}

	TEST_METHOD(TestMethod2)
	{
		// TODO: Your test code here
	}
};

TEST_CLASS(UnitTest2)
{
	TEST_METHOD(TestMethod1)
	{
		// TODO: Your test code here
	}

	TEST_METHOD(TestMethod2)
	{
		// TODO: Your test code here
	}
};
